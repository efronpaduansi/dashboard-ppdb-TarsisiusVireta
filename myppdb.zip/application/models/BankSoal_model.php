<?php


class BankSoal_model extends CI_Model{
    
}